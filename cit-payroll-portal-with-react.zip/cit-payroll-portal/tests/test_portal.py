"""Run:  python -m unittest discover -s tests -v"""
import datetime as dt
import io
import os
import sys
import tempfile
import unittest
from decimal import Decimal

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SAMPLES = os.path.join(ROOT, "samples")
sys.path.insert(0, ROOT)
os.environ["PORTAL_DATA_DIR"] = tempfile.mkdtemp(prefix="cit_portal_test_")

from openpyxl import Workbook, load_workbook  # noqa: E402

from payroll.config import DEFAULT_RULES  # noqa: E402
from payroll.engine import compute, generate, readiness, summary, to_baseline, validate  # noqa: E402
from payroll.exporter import build_workbook  # noqa: E402
from payroll.readers import read_baseline, read_table  # noqa: E402

D = Decimal
BASE = os.path.join(SAMPLES, "CIT_payroll_Oct-15-2026_Final.xlsx")
INV = os.path.join(SAMPLES, "sample_invoices_sep2026.xlsx")
HLT = os.path.join(SAMPLES, "sample_health_oct2026.xlsx")
RUN = dt.date(2026, 10, 15)


def fresh(inv=None):
    base = read_baseline(BASE)
    invoices, _ = read_table(inv or INV, "invoices")
    hi, _ = read_table(HLT, "health")
    return base, invoices, hi, generate(base, invoices, hi, DEFAULT_RULES, RUN)


class Engine(unittest.TestCase):
    def test_baseline_detects_one_time_rows(self):
        base = read_baseline(BASE)
        self.assertEqual(len(base["rows"]), 43)
        self.assertEqual(sorted(r["name"] for r in base["rows"] if r["one_time"]),
                         ["Pabba, Gokul Charan", "Pasumarthi, Avinash"])

    def test_regenerating_october_reproduces_every_row(self):
        base, _, _, st = fresh()
        old = {}
        for b in base["rows"]:
            if b["one_time"]:
                continue
            old[(b["emp_id"], b["name"], (b["vendor"] or "").lower(), b["block"])] = b
        self.assertEqual(len(st["rows"]), len(old))
        for r in st["rows"]:
            b = old[(r["emp_id"], r["name"], (r["vendor"] or "").lower(), r["block"])]
            c = compute(r)
            self.assertEqual(q(c["W"]), q(b["gross_raw"]), f"gross differs for {r['name']}")
            self.assertEqual(r["hours"], b["hours"], f"hours differ for {r['name']}")
            self.assertEqual(q(r.get("hi") or 0), q(b.get("hi") or 0), f"insurance differs for {r['name']}")
        s = summary(st)
        self.assertEqual(q(s["regular_gross"]), D("210446.70"))   # 219,687.91 less the two one-time rows
        self.assertEqual(q(s["mps_gross"]), D("138957.67"))
        self.assertEqual(q(s["hi_total"]), D("7639.33"))
        self.assertEqual(q(st["carrier_total"]), D("8148.63"))
        self.assertEqual(validate(st), [])

    def test_employer_paid_rule(self):
        _, _, _, st = fresh()
        row = next(r for r in st["rows"] if r["emp_id"] == "CIT-027")
        self.assertEqual(row["hi"], D("1171.35"))

    def test_split_rule_avuthu(self):
        _, _, _, st = fresh()
        rows = [r for r in st["rows"] if r["emp_id"] == "CIT-085"]
        self.assertEqual([r["hours"] for r in rows], [D("168"), D("34")])
        self.assertEqual(rows[1]["inv_hours_text"], "202-168")

    def test_expense_row_follows_parent_hours(self):
        _, _, _, st = fresh()
        exp = next(r for r in st["rows"] if "Expenses" in r["name"])
        par = next(r for r in st["rows"] if r["emp_id"] == exp["emp_id"] and "Expenses" not in r["name"])
        self.assertEqual(exp["hours"], par["hours"])
        c = compute(exp)
        self.assertEqual((c["AF"], c["AO"], c["X"]), (D(0), D(0), D(0)))

    def test_missing_invoice_is_blocking_not_guessed(self):
        wb = load_workbook(INV)
        ws = wb.active
        for r in range(ws.max_row, 3, -1):
            if ws.cell(r, 1).value == "CIT-089":
                ws.delete_rows(r)
        p = os.path.join(tempfile.mkdtemp(), "inv.xlsx")
        wb.save(p)
        _, _, _, st = fresh(p)
        row = next(r for r in st["rows"] if r["emp_id"] == "CIT-089")
        self.assertIsNone(row["hours"])
        rd = readiness(st)
        self.assertFalse(rd["can_download"])
        self.assertTrue(any(e["uid"] == row["uid"] for e in rd["errors"]))

    def test_new_employee_placeholder_needs_setup(self):
        wb = load_workbook(INV)
        ws = wb.active
        ws.insert_rows(4)
        for i, v in enumerate(["CIT-999", "Newperson, Nora", "Acme Corp", 160, 160, 70, None, None], 1):
            ws.cell(4, i, v)
        p = os.path.join(tempfile.mkdtemp(), "inv.xlsx")
        wb.save(p)
        _, _, _, st = fresh(p)
        row = next(r for r in st["rows"] if r["emp_id"] == "CIT-999")
        self.assertTrue(any(e["uid"] == row["uid"] and e["field"] == "cons_rate" for e in validate(st)))
        self.assertTrue(any(f["code"] == "new_employee" for f in st["flags"]))

    def test_rate_and_vendor_changes_are_flagged(self):
        wb = load_workbook(INV)
        ws = wb.active
        for r in range(4, ws.max_row + 1):
            if ws.cell(r, 1).value == "CIT-014" and ws.cell(r, 3).value == "Experis":
                ws.cell(r, 7, 71)        # consultant rate on invoice sheet differs from payroll
                ws.cell(r, 6, 72)        # invoice rate changed
        p = os.path.join(tempfile.mkdtemp(), "inv.xlsx")
        wb.save(p)
        _, _, _, st = fresh(p)
        codes = {f["code"] for f in st["flags"]}
        self.assertIn("consultant_rate_differs", codes)
        self.assertIn("invoice_rate_changed", codes)
        row = next(r for r in st["rows"] if r["emp_id"] == "CIT-014" and r["vendor"] == "Experis")
        self.assertEqual(row["cons_rate"], D("69.3"))   # payroll value is kept until a human accepts the change

    def test_next_month_baseline_roundtrip(self):
        base, invoices, hi, st = fresh()
        nb = to_baseline(st)
        st2 = generate(nb, invoices, hi, DEFAULT_RULES, dt.date(2026, 11, 15))
        self.assertEqual(st2["pay_period"], "10/01/2026-10/31/2026")
        self.assertEqual(len(st2["rows"]), len(st["rows"]))
        self.assertEqual(q(summary(st2)["regular_gross"]), q(summary(st)["regular_gross"]))


def q(x):
    return D(x).quantize(D("0.01"))


class Excel(unittest.TestCase):
    def test_workbook_has_formulas_and_text_is_never_a_formula(self):
        _, _, _, st = fresh()
        st["rows"][0]["name"] = "=HYPERLINK(\"http://x\")"
        wb = build_workbook(st, readiness(st))
        ws = wb.worksheets[0]
        self.assertTrue(str(ws["S2"].value).startswith("="))
        self.assertEqual(ws["C2"].data_type, "s")
        self.assertIn("Checks", wb.sheetnames)


class Web(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import app as portal
        portal.app.config["TESTING"] = True
        cls.c = portal.app.test_client()

    def upload_baseline(self):
        with open(BASE, "rb") as f:
            r = self.c.post("/baseline", data={"file": (f, "oct.xlsx")}, content_type="multipart/form-data", follow_redirects=True)
        self.assertEqual(r.status_code, 200)

    def new_month(self, run="2026-10-15"):
        with open(INV, "rb") as a, open(HLT, "rb") as b:
            return self.c.post("/month/new", data={"run_date": run, "invoices": (a, "inv.xlsx"), "health": (b, "hi.xlsx")},
                               content_type="multipart/form-data", follow_redirects=False)

    def test_full_flow(self):
        self.upload_baseline()
        r = self.new_month()
        self.assertEqual(r.status_code, 302)
        j = self.c.get("/api/month/2026-10").get_json()
        self.assertEqual(j["errors"], [])
        self.assertTrue(j["can_download"])
        self.assertFalse(j["can_close"])                   # warnings still need acknowledging
        self.assertEqual(j["summary"]["regular_gross"], "210446.70")
        # edit hours -> everything recalculates server side
        row = next(x for x in j["rows"] if x["emp_id"] == "CIT-089")
        j2 = self.c.post(f"/api/month/2026-10/row/{row['uid']}", json={"hours": "100"}).get_json()
        r2 = next(x for x in j2["rows"] if x["uid"] == row["uid"])
        self.assertEqual(r2["W"], "4800.00")
        # bad input is rejected, not stored
        bad = self.c.post(f"/api/month/2026-10/row/{row['uid']}", json={"hours": "abc"})
        self.assertEqual(bad.status_code, 400)
        self.c.post(f"/api/month/2026-10/row/{row['uid']}", json={"hours": "158.35"})
        # blank hours -> blocking error, final download refused (draft only)
        self.c.post(f"/api/month/2026-10/row/{row['uid']}", json={"hours": ""})
        self.assertFalse(self.c.get("/api/month/2026-10").get_json()["can_download"])
        self.assertEqual(self.c.get("/month/2026-10/download").status_code, 302)
        d = self.c.get("/month/2026-10/download?draft=1")
        self.assertIn("DRAFT", d.headers["Content-Disposition"])
        self.c.post(f"/api/month/2026-10/row/{row['uid']}", json={"hours": "158.35"})
        # acknowledge + close
        self.c.post("/api/month/2026-10/ack_all", json={})
        j = self.c.get("/api/month/2026-10").get_json()
        self.assertTrue(j["can_close"], j["errors"] or [f for f in j["flags"] if not f["acked"] and f["severity"] != "info"])
        dl = self.c.get("/month/2026-10/download")
        self.assertEqual(dl.status_code, 200)
        wb = load_workbook(io.BytesIO(dl.data))
        self.assertEqual(wb.worksheets[0].title, "Oct-15 payroll")
        self.c.post("/month/2026-10/close")
        self.assertEqual(self.c.get("/api/month/2026-10").get_json()["month"]["status"], "closed")
        # closed month is read-only
        self.assertEqual(self.c.post(f"/api/month/2026-10/row/{row['uid']}", json={"hours": "1"}).status_code, 409)
        # next month builds from the closed month with no baseline re-upload
        r = self.new_month("2026-11-15")
        self.assertEqual(r.status_code, 302)
        n = self.c.get("/api/month/2026-11").get_json()
        self.assertEqual(n["month"]["pay_period"], "10/01/2026-10/31/2026")

    def test_wrong_file_gives_helpful_message(self):
        self.upload_baseline()
        wb = Workbook()
        wb.active.append(["Foo", "Bar"])
        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)
        with open(HLT, "rb") as b:
            r = self.c.post("/month/new", data={"run_date": "2026-12-15", "invoices": (buf, "x.xlsx"), "health": (b, "h.xlsx")},
                            content_type="multipart/form-data", follow_redirects=True)
        self.assertIn(b"Could not find the required columns", r.data)


if __name__ == "__main__":
    unittest.main()
