"""Creates SYNTHETIC sample inputs from the Oct-15-2026 payroll so the portal can be tried end-to-end.
Real invoice / health files from CIT will have their own headers - map them in Settings if needed."""
import sys, os
from openpyxl import Workbook
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from payroll.readers import read_baseline
from payroll.engine import is_expense
from payroll.util import num

HERE = os.path.dirname(__file__)
base = read_baseline(os.path.join(HERE, "CIT_payroll_Oct-15-2026_Final.xlsx"))

wb = Workbook(); ws = wb.active; ws.title = "Sep 2026 invoices"
ws.append(["CIT Invoice Summary - September 2026"]); ws.append([])
ws.append(["Employee ID", "Employee Name", "Vendor Name", "Invoice Hours", "Payroll Hours", "Invoice Rate", "Consultant Rate", "Consultant %"])
seen = {}
for r in base["rows"]:
    if r["one_time"] or is_expense(r):
        continue
    key = (r["emp_id"], (r["vendor"] or "").lower())
    if key in seen:           # Avuthu: one invoice line (202 hrs) covers both payroll rows
        continue
    seen[key] = 1
    inv_hours = 202 if r["emp_id"] == "CIT-085" else num(r["inv_hours"])
    pay_hours = 202 if r["emp_id"] == "CIT-085" else num(r["hours"])
    ws.append([r["emp_id"], r["name"], r["vendor"], inv_hours, pay_hours, num(r["inv_rate"]), num(r["cons_rate"]), num(r["cons_pct"])])
ws.append(["TOTAL"])
wb.save(os.path.join(HERE, "sample_invoices_sep2026.xlsx"))

hb = Workbook(); hs = hb.active; hs.title = "Carrier"
hs.append(["Member Name", "Coverage Tier", "Premium"])
for r in base["rows"]:
    if r["hi"] and not r["one_time"]:
        carrier = 1680.65 if r["emp_id"] == "CIT-027" else num(r["hi"])   # carrier bills full premium; employer share is a Settings rule
        hs.append([r["name"], "FAM" if carrier == 1680.65 else ("ESP" if carrier == 1298.69 else "EMP"), carrier])
hb.save(os.path.join(HERE, "sample_health_oct2026.xlsx"))
print("samples written")
