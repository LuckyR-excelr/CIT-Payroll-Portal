(() => {
  const MID = window.MONTH_ID, RO = window.READONLY;
  let data = null, filter = "", onlyIssues = false;
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const money = (s) => s === "" || s == null ? "" : Number(s).toLocaleString("en-US", {minimumFractionDigits: 2, maximumFractionDigits: 2});
  const hrs = (s) => s === "" || s == null ? "" : String(Number(Number(s).toFixed(3)));
  const toast = (m, err) => { const t = $("#toast"); t.textContent = m; t.className = "toast" + (err ? " err" : ""); t.style.display = "block"; clearTimeout(t._h); t._h = setTimeout(() => t.style.display = "none", 4200); };

  async function api(url, body) {
    const r = await fetch(url, body === undefined ? {} : {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)});
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { toast(j.error || "Request failed", true); throw new Error(j.error); }
    return j;
  }
  const load = async () => { data = await api(`/api/month/${MID}`); render(); };
  const apply = (j) => { data = j; render(); };

  function render() {
    const m = data.month, s = data.summary;
    $("#title").textContent = "Payroll – " + new Date(m.run_date + "T00:00").toLocaleDateString("en-US", {month: "long", day: "numeric", year: "numeric"});
    $("#subtitle").innerHTML = `Pay period ${esc(m.pay_period)} · <span class="badge ${m.status === "closed" ? "b-ok" : "b-warn"}">${esc(m.status)}</span> · invoices: ${esc(m.files.invoices || "")} · insurance: ${esc(m.files.health || "")}`;
    const nErr = data.errors.length, nWarn = data.unacked, bad = data.checks.filter(c => !c.ok).length;
    let b = "";
    if (m.status === "closed") b = `<div class="banner ok">✔ Closed – this payroll is the baseline for next month.</div>`;
    else if (nErr || bad) b = `<div class="banner err">✖ ${nErr} error(s)${bad ? ` and ${bad} failing check(s)` : ""} to fix before the final download. Rows with a red bar need attention.</div>`;
    else if (nWarn) b = `<div class="banner warn">⚠ No errors. ${nWarn} flag(s) to acknowledge on the Flags tab before closing the month.</div>`;
    else b = `<div class="banner ok">✔ Ready – no errors, all checks pass, all flags acknowledged.</div>`;
    $("#banner").innerHTML = b;
    const stat = (k, v, sub) => `<div class="card stat"><div class="k">${k}</div><div class="v">${v}</div><div class="s">${sub || ""}</div></div>`;
    $("#stats").innerHTML =
      stat("Employees", s.employees, `${s.manual_employees} manual · ${s.auto_employees} auto`) +
      stat("Regular gross", "$" + money(s.regular_gross), `manual $${money(s.manual_gross)}`) +
      stat("MPS gross", "$" + money(s.mps_gross), `${s.mps_rows} rows`) +
      stat("Health insurance", "$" + money(s.hi_total), data.carrier_total ? `carrier total $${money(data.carrier_total)}` : "") +
      stat("Net payable", "$" + money(s.net_total), "after deductions") +
      stat("Advance after", s.advance_after ? "$" + money(s.advance_after) : "–", s.advance_before ? `before $${money(s.advance_before)}` : "");
    $("#flagCount").textContent = nWarn + nErr;
    $("#dl").href = `/month/${MID}/download` + (data.can_download ? "" : "?draft=1");
    $("#dl").textContent = data.can_download ? "⬇ Download Excel" : "⬇ Download DRAFT (has errors)";
    $("#closeBtn").disabled = RO || !data.can_close;
    renderGrid(); renderFlags(); renderChecks();
  }

  const F = (row, f) => data.rows ? "" : "";
  function inp(row, f, cls) {
    const err = data.errors.some(e => e.uid === row.uid && e.field === f);
    return `<input class="${cls || ""} ${err ? "bad" : ""}" data-uid="${row.uid}" data-field="${f}" value="${esc(row[f])}" ${RO ? "disabled" : ""}>`;
  }

  function renderGrid() {
    const active = document.activeElement, keep = active && active.dataset && active.dataset.uid ? [active.dataset.uid, active.dataset.field] : null;
    const wrap = document.querySelector(".gridwrap"), sy = wrap.scrollTop, sx = wrap.scrollLeft;
    const flagsById = Object.fromEntries(data.flags.map(f => [f.id, f]));
    const rowsErr = new Set(data.errors.map(e => e.uid));
    const head = ["", "ID", "Employee", "Vendor", "Hours", "Inv hrs", "Inv rate", "Cons rate", "Cons %", "Pay rate", "Gross (W)", "Bonus", "Deduct", "Health ins", "Total ded", "Net (AC)", "ADP rate", "ADP hrs", "Pay hrs", "ADP rate ovr", "Pay hrs ovr", ""];
    let h = "<thead><tr>" + head.map(x => `<th>${x}</th>`).join("") + "</tr></thead><tbody>";
    const q = filter.toLowerCase();
    ["regular", "mps"].forEach(block => {
      const rows = data.rows.filter(r => r.block === block).filter(r => !q || (r.name + r.emp_id + r.vendor).toLowerCase().includes(q))
        .filter(r => !onlyIssues || r.flag_ids.some(id => { const f = flagsById[id]; return f && f.severity !== "info"; }) || rowsErr.has(r.uid));
      if (!rows.length) return;
      const tot = rows.filter(r => !r.excluded).reduce((a, r) => a + Number(r.W || 0), 0);
      h += `<tr class="blockhead"><td colspan="${head.length}">${block === "regular" ? "REGULAR PAYROLL" : "MPS PAYROLL"} · ${rows.length} rows · gross $${money(tot)}</td></tr>`;
      rows.forEach(r => {
        const fl = r.flag_ids.map(id => flagsById[id]).filter(f => f && f.severity !== "info" && !f.acked && !f.resolved);
        const cls = (r.excluded ? "excluded " : "") + (rowsErr.has(r.uid) ? "err" : fl.length ? "warn" : "");
        h += `<tr class="${cls}"><td>${r.is_expense ? "💲" : ""}</td><td>${inp(r, "emp_id", "t")}</td><td>${inp(r, "name", "t")}</td><td>${inp(r, "vendor", "t")}</td>` +
          `<td>${inp(r, "hours")}</td><td class="n calc">${esc(r.inv_hours)}</td><td>${inp(r, "inv_rate")}</td><td>${inp(r, "cons_rate")}</td><td>${inp(r, "cons_pct")}</td>` +
          `<td class="n calc">${money(r.S)}</td><td class="n calc tot">${money(r.W)}</td><td>${inp(r, "bonus")}</td><td>${inp(r, "deduct")}</td><td>${inp(r, "hi")}</td>` +
          `<td class="n calc">${money(r.AB)}</td><td class="n calc tot">${money(r.AC)}</td><td class="n calc">${money(r.AE)}</td><td class="n calc">${hrs(r.AF)}</td><td class="n calc">${hrs(r.AO)}</td>` +
          `<td>${inp(r, "ae_override")}</td><td>${inp(r, "ao_override")}</td>` +
          `<td>${RO ? "" : `<button class="btn sm" data-act="exclude" data-uid="${r.uid}">${r.excluded ? "Include" : "Skip"}</button> <button class="btn sm danger" data-act="delete" data-uid="${r.uid}">✕</button>`}</td></tr>`;
      });
    });
    $("#grid").innerHTML = h + "</tbody>";
    wrap.scrollTop = sy; wrap.scrollLeft = sx;
    if (keep) { const el = document.querySelector(`input[data-uid="${keep[0]}"][data-field="${keep[1]}"]`); if (el) el.focus(); }
  }

  function renderFlags() {
    const order = {error: 0, warn: 1, info: 2};
    const rows = data.errors.map(e => ({severity: "error", who: e.who, message: e.message, id: null, acked: false, live: true}))
      .concat(data.flags.filter(f => !(f.severity === "error" && f.resolved)).sort((a, b) => order[a.severity] - order[b.severity]));
    if (!rows.length) { $("#flagList").innerHTML = `<p class="hint">Nothing to review.</p>`; return; }
    $("#flagList").innerHTML = rows.map(f => {
      const bc = f.severity === "error" ? "b-err" : f.severity === "warn" ? "b-warn" : "b-info";
      let act = "";
      if (!RO && f.id && f.severity === "warn") {
        if (f.suggested && Object.keys(f.suggested).length) act += `<button class="btn sm" data-flag="${f.id}" data-apply="1">Use invoice value</button> `;
        act += `<button class="btn sm" data-flag="${f.id}" data-ack="${f.acked ? 0 : 1}">${f.acked ? "Undo" : "Acknowledge"}</button>`;
      }
      return `<div class="flagrow ${f.acked ? "acked" : ""}"><span class="badge ${bc}">${f.severity.toUpperCase()}</span><div style="flex:1"><div class="who">${esc(f.who || "General")}</div><div>${esc(f.message)}</div></div><div>${f.acked ? '<span class="badge b-ok">acknowledged</span>' : act}</div></div>`;
    }).join("");
  }

  function renderChecks() {
    $("#checkList").innerHTML = data.checks.map(c => `<div class="checkrow"><div>${esc(c.name)}<div class="hint">${esc(c.detail)}</div></div><span class="badge ${c.ok ? "b-ok" : "b-err"}">${c.ok ? "OK" : "CHECK"}</span></div>`).join("");
  }

  // ---- events
  document.addEventListener("change", async (e) => {
    const t = e.target;
    if (!t.dataset || !t.dataset.uid) return;
    try { apply(await api(`/api/month/${MID}/row/${t.dataset.uid}`, {[t.dataset.field]: t.value})); } catch (_) { load(); }
  });
  document.addEventListener("click", async (e) => {
    const b = e.target.closest("button"); if (!b) return;
    try {
      if (b.dataset.act === "exclude") apply(await api(`/api/month/${MID}/row/${b.dataset.uid}/exclude`, {}));
      else if (b.dataset.act === "delete") { if (confirm("Delete this row?")) apply(await api(`/api/month/${MID}/row/${b.dataset.uid}/delete`, {})); }
      else if (b.dataset.flag) apply(await api(`/api/month/${MID}/flag/${encodeURIComponent(b.dataset.flag)}`, b.dataset.apply ? {apply: true} : {ack: b.dataset.ack === "1"}));
    } catch (_) {}
  });
  $("#ackAll").onclick = async () => apply(await api(`/api/month/${MID}/ack_all`, {}));
  $("#q").oninput = (e) => { filter = e.target.value; renderGrid(); };
  $("#onlyIssues").onchange = (e) => { onlyIssues = e.target.checked; renderGrid(); };
  document.querySelectorAll(".tab").forEach(t => t.onclick = () => {
    document.querySelectorAll(".tab,.pane").forEach(x => x.classList.remove("active"));
    t.classList.add("active"); $("#pane-" + t.dataset.tab).classList.add("active");
  });
  $("#addBtn").onclick = async () => {
    const body = {block: $("#a_block").value};
    ["emp_id", "name", "vendor", "hours", "cons_rate", "cons_pct", "inv_rate"].forEach(k => body[k] = $("#a_" + k).value);
    try { apply(await api(`/api/month/${MID}/row`, body)); toast("Row added – complete the remaining fields in the grid."); document.querySelector('[data-tab="grid"]').click(); } catch (_) {}
  };
  if (RO) document.querySelector('[data-tab="add"]').style.display = "none";
  load();
})();
