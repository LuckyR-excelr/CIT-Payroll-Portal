import { useState } from 'react';
import { FileSpreadsheet, UploadCloud, ShieldCheck, ClipboardCheck, Download, CircleAlert, CalendarDays, ChevronRight } from 'lucide-react';

const requiredFiles = [
  { key: 'baseline', title: 'Previous payroll workbook', hint: 'Use the last approved payroll as the employee and format baseline.' },
  { key: 'invoices', title: 'CIT invoices workbook', hint: 'Upload the invoice file for the payroll period being prepared.' },
  { key: 'insurance', title: 'Health insurance workbook', hint: 'Upload the insurance carrier file for the same period.' }
];

function App() {
  const [files, setFiles] = useState({});
  const [runDate, setRunDate] = useState('2026-11-15');
  const [notice, setNotice] = useState('');
  const allSelected = requiredFiles.every(f => files[f.key]);

  function selectFile(key, file) {
    setFiles(prev => ({ ...prev, [key]: file || null }));
    setNotice('');
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-icon"><FileSpreadsheet size={22}/></div><div><strong>CIT Payroll</strong><span>PAYROLL OPERATIONS</span></div></div>
      <div className="nav-label">WORKSPACE</div>
      <div className="nav-item active"><ClipboardCheck size={18}/> Payroll workspace</div>
      <div className="nav-item"><ShieldCheck size={18}/> Review & approvals</div>
      <div className="sidebar-note"><ShieldCheck size={17}/><div><b>Payroll data is sensitive</b><p>Use only approved files and keep generated payroll workbooks in a secure location.</p></div></div>
    </aside>
    <main className="main">
      <header className="topbar"><div><span className="eyebrow">PAYROLL OPERATIONS / MONTHLY RUN</span><h1>Payroll workspace</h1><p>Prepare, validate, review, and export your monthly CIT payroll.</p></div><div className="secure-pill"><ShieldCheck size={16}/> Secure workflow</div></header>
      <section className="summary-grid">
        <div className="summary-card"><span>PAYROLL RUN</span><strong>{runDate}</strong><small><CalendarDays size={14}/> Planned run date</small></div>
        <div className="summary-card"><span>INPUT FILES</span><strong>{Object.values(files).filter(Boolean).length} <em>/ 3</em></strong><small>Required Excel workbooks</small></div>
        <div className="summary-card"><span>WORKFLOW STATUS</span><strong className="status-text">Not generated</strong><small>Upload files to begin validation</small></div>
      </section>
      <section className="panel">
        <div className="panel-heading"><div><h2>1. Upload payroll source files</h2><p>Choose the real Excel files for this payroll cycle. Do not use sample files for final payroll.</p></div><span className="step-badge">STEP 1 OF 3</span></div>
        <label className="date-label" htmlFor="run-date">Payroll run date</label>
        <input id="run-date" className="date-input" type="date" value={runDate} onChange={e=>setRunDate(e.target.value)}/>
        <div className="upload-grid">{requiredFiles.map(item=><div className={'upload-card '+(files[item.key]?'selected':'')} key={item.key}>
          <div className="upload-icon"><FileSpreadsheet size={22}/></div><h3>{item.title}</h3><p>{item.hint}</p>
          <label className="file-button"><UploadCloud size={16}/>{files[item.key]?'Replace file':'Choose Excel file'}<input type="file" accept=".xlsx,.xls,.xlsm,.csv" onChange={e=>selectFile(item.key,e.target.files?.[0])}/></label>
          {files[item.key]&&<div className="file-name"><ShieldCheck size={15}/><span>{files[item.key].name}</span></div>}
        </div>)}</div>
        <div className="notice"><CircleAlert size={18}/><p><b>Important:</b> This React screen is the UI starter. It does not yet send these files to the payroll calculation engine. Use the existing Python/Flask portal to generate and validate payroll until the API integration is completed.</p></div>
        <div className="panel-footer"><span>{allSelected?'All three files selected.':'Select all three required files to complete the upload checklist.'}</span><button className="primary-button" onClick={()=>setNotice(allSelected?'Upload checklist complete. The React UI is not connected to the payroll engine yet; open the Flask portal using the README instructions.':'Please choose all three required files first.')}><span>Continue to validation</span><ChevronRight size={17}/></button></div>
        {notice&&<div className="result-message">{notice}</div>}
      </section>
      <section className="panel lower-panel"><div className="panel-heading"><div><h2>2. Review & validate</h2><p>Resolve missing information and review any flagged changes before exporting.</p></div></div><div className="workflow-steps"><div><span>01</span><b>Upload sources</b><small>Payroll, invoices, insurance</small></div><div><span>02</span><b>Validate rows</b><small>Missing values and mismatches</small></div><div><span>03</span><b>Review & export</b><small>Download draft or approved workbook</small></div></div></section>
      <footer> C I T Payroll Portal <span>• Keep employee and payroll information confidential.</span></footer>
    </main>
  </div>;
}

export default App;
