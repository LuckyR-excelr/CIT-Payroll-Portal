# CIT Payroll Portal

A local web portal that builds the monthly CIT payroll workbook from three uploads — **last payroll**,
**CIT invoice sheet** and **health-insurance file** — and exports it in the same 46-column layout
(A–AT) with live Excel formulas. Nothing is typed in or hard-coded: employees, vendors, rates and
ADP ids come from last month's payroll; hours come from the invoice sheet; insurance comes from the
carrier file.

## Quick start (VS Code)

1. Install Python 3.10+ and VS Code (with the *Python* extension).
2. **File → Open Folder…** → choose `cit-payroll-portal`.
3. Open the terminal (**Ctrl+`**) and run:

   Windows
   ```
   py -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python app.py
   ```
   Mac / Linux
   ```
   python3 -m venv .venv && . .venv/bin/activate
   pip install -r requirements.txt
   python app.py
   ```
   (or just double-click `run.bat` / run `./run.sh`)
4. Open **http://127.0.0.1:5000**.

Press **F5** in VS Code to run with the debugger (`CIT Payroll Portal (run)`), or run the task
**Run tests**.

## Monthly routine

1. **One time:** Dashboard → upload last payroll (e.g. `CIT payroll Oct-15`) → *Load payroll*.
2. **Every month:** *New month* → pick the run date → upload the invoice sheet and the health-insurance
   file → *Generate payroll*.
3. Review. Rows with a red bar have **errors** (must be fixed), amber bars have **flags** (accept or fix).
   Any white cell can be edited; the server recalculates everything.
4. **Download Excel.** When there are no errors and all checks pass, the file is final. Otherwise only a
   clearly marked DRAFT can be downloaded.
5. **Close month.** The closed payroll automatically becomes next month's baseline — you never upload
   the previous payroll again.

The pay period is always the previous calendar month (run on Oct 15 → 09/01–09/30).

## How each column is produced

| Column(s) | Source |
|---|---|
| ID, name, term, mode, vendor, LCA wages, ADP ids (AI–AT), billing, primary/secondary | Last payroll (baseline) |
| Payroll hours (M), validation hours (N), invoice rate (O), vendor (P) | Invoice sheet |
| Consultant rate (Q) and % (R) | Last payroll — an invoice-sheet difference is **flagged**, never silently applied |
| Pay rate, gross, net, ADP hours, pay hours (S, U, W, X, AB, AC, AE, AF, AO) | Excel formulas (same as your sheet) |
| Health insurance (AA) | Carrier file − employer-paid portion (Settings) |
| Advance (Z) | Entered in the grid; advance-after = before − deductions |

Carried automatically: ADP-rate overrides (e.g. Datla 2nd check, Mamillapalli), the "(Expenses)" row
follows its employee's hours, and rows paid for a different period (one-time catch-ups such as a June
or July payment) are **not** carried into the next month — the portal lists them so you can add them back.

## What the portal checks

* Missing hours / rate / % → **error** (no value is ever guessed)
* Employee in last payroll but not in the invoice sheet → error; in the invoice sheet but not in payroll → "new employee" error
* Invoice-rate, vendor or consultant-rate/% change, insurance change, hours swing > 25 %, hours > 250 → flag
* Insurance: deducted + employer-paid + unmatched carrier lines = carrier file total
* Net gross = net gross amount + bonus − deductions; ADP hours × ADP rate = net gross amount; advance roll-forward
* The exported workbook contains a **Checks** sheet with live formulas, a **Review Flags** sheet and an **Inputs** sheet

## Settings

* **Column names** – the portal finds columns by header text (employee name, hours, premium …).
  If your invoice or insurance file uses other headings, add them here.
* **Employer-paid insurance** – e.g. `CIT-027 → 509.30`.
* **Hours split** – e.g. `CIT-085 → 168` (Regular row 168 hrs, the rest on the MPS row).

## Important notes

* The invoice and insurance formats were not available when this was built; the files in `samples/` are
  **synthetic**, derived from the Oct-15 payroll. If real files fail to load, the error shows the columns
  that were found — add those names in Settings. Always compare the first generated month with your manual sheet.
* Data lives in the `data/` folder (JSON + uploaded files). Back it up by copying the folder.
* The portal is for one computer. If you host it for others, set `PORTAL_PASSWORD` (HTTP login) and serve it
  over HTTPS behind a proper server — payroll data is sensitive.
* Tests: `python -m unittest discover -s tests -v` (re-generates October from October's inputs and
  checks every row against your sheet).

## Project layout

```
app.py                  web routes + JSON API
payroll/readers.py      reads baseline payroll, invoice sheet, insurance file
payroll/engine.py       calculation, matching, flags, validation, checks
payroll/exporter.py     Excel writer (formulas, Checks, Review Flags, Inputs)
payroll/store.py        JSON storage in data/
templates/, static/     the screens
samples/                synthetic sample inputs (python samples/make_samples.py)
tests/                  unit + end-to-end tests
```

\n## React UI starter (optional)\n\nThis ZIP now also includes a Vite + React UI starter in `src/` with `package.json`. It is a separate visual starter and is **not yet connected to the Flask payroll calculation/API**. For real payroll generation, use the existing Flask portal instructions above (`python app.py`, then open `http://127.0.0.1:5000`).\n\nTo preview the React UI: install Node.js LTS, open a terminal in this folder, run `npm install`, then `npm run dev` and open the local address Vite prints (normally `http://localhost:5173`). Do not use the React starter to generate or approve payroll until API integration and security review are completed.\n