"""CIT payroll engine: readers, calculation engine, Excel exporter."""
