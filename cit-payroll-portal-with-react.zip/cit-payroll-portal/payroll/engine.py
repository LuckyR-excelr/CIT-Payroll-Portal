"""Payroll calculation engine. Pure functions on plain dicts -> easy to test.

Principles
  * Nothing is guessed. If an input is missing or ambiguous the row gets an ERROR (blocks the final export).
  * Anything that differs from last month (rates, vendor, insurance, hours swing) is a FLAG that a human acknowledges.
  * All maths in Decimal; Excel receives live formulas so the workbook re-computes itself.
"""
import hashlib
import uuid
from decimal import Decimal

from .columns import COLUMNS, NUMERIC_KEYS
from .util import (D, ZERO, q2, trunc3, id_key, name_key, same_employee, vendor_match, pay_period,
                   fmt_period, to_date)
import datetime as dt

INPUT_KEYS = [c[2] for c in COLUMNS if c[2]]
HOURS_SWING = Decimal("0.25")
HOURS_HIGH = Decimal("250")


def _uid():
    return uuid.uuid4().hex[:8]


def fmt_num(d):
    if d is None:
        return ""
    s = format(d.normalize(), "f")
    return s


def is_expense(row):
    return "(expense" in (row.get("name") or "").lower()


def emp_key(row):
    return id_key(row.get("emp_id")) or name_key(row.get("name"))


# ------------------------------------------------------------------ calculation
def compute(row):
    """Derived columns S,U,W,X,AB,AC,AE,AF,AO for one row (mirrors the Excel formulas)."""
    Q, R, M = row.get("cons_rate"), row.get("cons_pct"), row.get("hours")
    T, V, Y = row.get("expenses") or ZERO, row.get("paid_exp") or ZERO, row.get("bonus") or ZERO
    Z, AA = row.get("deduct") or ZERO, row.get("hi") or ZERO
    S = Q * R if (Q is not None and R is not None) else None
    U = S * M - T if (S is not None and M is not None) else None
    W = U - V if U is not None else None
    expense = is_expense(row)
    X = ZERO if expense else (W / S if (W is not None and S) else None)
    AB = Z + AA
    AC = W + Y - AB if W is not None else None
    AE = row.get("ae_override") if row.get("ae_override") is not None else S
    AF = ZERO if expense else (W / AE if (W is not None and AE) else None)
    if row.get("ao_override") is not None:
        AO = row["ao_override"]
    elif expense:
        AO = ZERO
    elif row.get("ae_override") is not None:
        AO = trunc3(AF) if AF is not None else None
    else:
        AO = M
    return {"S": S, "U": U, "W": W, "X": X, "AB": AB, "AC": AC, "AE": AE, "AF": AF, "AO": AO}


# ------------------------------------------------------------------ flags
def make_flag(severity, code, message, row=None, field=None, suggested=None):
    uid = row["uid"] if row else None
    return {"id": f"{code}:{uid or '-'}:{field or '-'}:{hashlib.md5(message.encode()).hexdigest()[:6]}", "severity": severity,
            "code": code, "uid": uid, "field": field, "message": message,
            "suggested": {k: str(v) for k, v in (suggested or {}).items()}, "acked": False,
            "who": (f"{row.get('name', '')} · {row.get('vendor', '')}".strip(" ·") if row else "")}


# ------------------------------------------------------------------ generation
def new_row_from_baseline(b, run_date):
    start, end = pay_period(run_date)
    r = {k: b.get(k) for k in INPUT_KEYS}
    r.update({
        "uid": _uid(), "block": b.get("block", "regular"),
        "comments": "", "expenses": None, "paid_exp": None, "bonus": None, "deduct": None, "hi": None,
        "hours": None, "inv_hours": None, "inv_hours_text": None, "inv_status": "",
        "pp_month": (run_date - dt.timedelta(days=1)).isoformat(),
        "pay_period": fmt_period(start, end), "pp_start": start.isoformat(), "pp_end": end.isoformat(),
        "ae_override": b.get("ae_override"), "ao_override": b.get("ao_override"),
        "excluded": False, "parent_uid": None, "hi_carrier": None, "hi_employer": None,
    })
    return r


def generate(baseline, invoices, hi_recs, rules, run_date):
    run_date = to_date(run_date)
    start, end = pay_period(run_date)
    flags, rows = [], []
    base_rows = [b for b in baseline["rows"] if not b.get("one_time")]
    base_by_uid = {}
    for b in baseline["rows"]:
        if b.get("one_time"):
            flags.append(make_flag("info", "one_time_dropped",
                                   f"One-time row from last payroll not carried forward: {b['name']} · {b.get('vendor') or ''} "
                                   f"({b.get('pay_period')}, {fmt_num(b.get('hours'))} hrs). Add it back manually if it repeats."))
    for b in base_rows:
        r = new_row_from_baseline(b, run_date)
        # remember last month's values for comparisons
        r["_prev"] = {"hours": b.get("hours"), "inv_rate": b.get("inv_rate"), "cons_rate": b.get("cons_rate"),
                      "cons_pct": b.get("cons_pct"), "vendor": b.get("vendor"), "hi": b.get("hi"),
                      "deduct": b.get("deduct")}
        # carry ADP overrides
        S_prev = b["cons_rate"] * b["cons_pct"] if (b.get("cons_rate") is not None and b.get("cons_pct") is not None) else None
        if r["ae_override"] is None and b.get("ae_raw") is not None and S_prev is not None \
                and abs(b["ae_raw"] - S_prev) > Decimal("0.0005"):
            r["ae_override"] = b["ae_raw"]
            flags.append(make_flag("warn", "adp_override_carried",
                                   f"ADP rate {b['ae_raw']} (differs from pay rate {S_prev.normalize()}) carried from last payroll. "
                                   "Confirm it is still correct.", r, "ae_override"))
        if r["ao_override"] is None and b.get("ao_raw") == ZERO and (b.get("hours") or ZERO) > 0 and not is_expense(b):
            r["ao_override"] = ZERO
            flags.append(make_flag("warn", "ao_zero_carried",
                                   "Pay Hours were 0 last month (separate/2nd check). Carried forward - confirm.", r, "ao_override"))
        if (b.get("deduct") or ZERO) > 0:
            flags.append(make_flag("info", "advance_prev",
                                   f"Had an advance/deduction of {b['deduct']} last month. Re-enter it if it continues.", r, "deduct"))
        rows.append(r)

    # ---- link expense rows to the parent row
    for r in rows:
        if is_expense(r):
            for p in rows:
                if not is_expense(p) and same_employee(r["emp_id"], r["name"], p["emp_id"], p["name"]):
                    r["parent_uid"] = p["uid"]
                    break

    # ---- match invoice lines -> payroll rows
    used = set()
    groups = {}
    for r in rows:
        if is_expense(r):
            continue
        groups.setdefault((emp_key(r), _vkey(r.get("vendor"))), []).append(r)
    emp_row_count = {}
    for r in rows:
        if not is_expense(r):
            emp_row_count[emp_key(r)] = emp_row_count.get(emp_key(r), 0) + 1

    for (ek, _vk), grp in groups.items():
        first = grp[0]
        cand = [i for i, inv in enumerate(invoices) if same_employee(first["emp_id"], first["name"], inv["id"], inv["name"])]
        if not cand:
            for r in grp:
                flags.append(make_flag("error", "missing_invoice",
                                       "No line for this employee in the invoice sheet. Enter hours manually, or exclude/delete the row.", r, "hours"))
            continue
        vm = [i for i in cand if invoices[i].get("vendor") and vendor_match(first.get("vendor"), invoices[i]["vendor"])]
        if not vm:
            no_vendor_col = all(not invoices[i].get("vendor") for i in cand)
            if (no_vendor_col and emp_row_count[ek] == len(grp)) or (emp_row_count[ek] == len(grp) == 1 and len(cand) == 1):
                vm = cand
                if not no_vendor_col:
                    flags.append(make_flag("warn", "vendor_changed",
                                           f"Vendor on invoice sheet is '{invoices[cand[0]]['vendor']}', last payroll had '{first.get('vendor')}'. "
                                           "Invoice sheet value used.", first, "vendor",
                                           {"vendor": invoices[cand[0]]["vendor"]}))
                    first["vendor"] = invoices[cand[0]]["vendor"]
            else:
                vendors = ", ".join(sorted({invoices[i].get("vendor") or "?" for i in cand}))
                for r in grp:
                    flags.append(make_flag("error", "ambiguous_invoice",
                                           f"Invoice sheet has lines for this employee under other vendor(s): {vendors}. Cannot tell which belongs here - enter hours manually.", r, "hours"))
                continue
        vm = [i for i in vm if i not in used]
        if not vm:
            for r in grp:
                flags.append(make_flag("error", "missing_invoice", "Invoice line already used by another row.", r, "hours"))
            continue
        used.update(vm)
        recs = [invoices[i] for i in vm]
        inv_total = sum((x.get("invoice_hours") if x.get("invoice_hours") is not None else x.get("payroll_hours")) or ZERO for x in recs)
        pay_total = sum((x.get("payroll_hours") if x.get("payroll_hours") is not None else
                         (x.get("invoice_hours") or ZERO)) for x in recs)
        if len(recs) > 1:
            flags.append(make_flag("info", "multiple_invoice_lines",
                                   f"{len(recs)} invoice lines summed ({fmt_num(inv_total)} hrs).", first, "hours"))
        if len(grp) == 1:
            first["hours"], first["inv_hours"] = pay_total, inv_total
        else:
            cap = _split_cap(rules, first)
            if cap is None:
                for r in grp:
                    flags.append(make_flag("error", "ambiguous_split",
                                           f"{len(grp)} payroll rows share this employee+vendor but there is no split rule in Settings. Enter hours manually.", r, "hours"))
            else:
                first["hours"], first["inv_hours"] = min(pay_total, cap), inv_total
                rest = pay_total - cap
                grp[1]["hours"] = rest if rest > 0 else ZERO
                grp[1]["inv_hours_text"] = f"{fmt_num(inv_total)}-{fmt_num(cap)}"
                flags.append(make_flag("info", "split_applied",
                                       f"Split rule: first row {fmt_num(first['hours'])} hrs, second row {fmt_num(grp[1]['hours'])} hrs (invoice total {fmt_num(inv_total)}).", grp[1], "hours"))
        rec0 = recs[0]
        for r in grp:
            if rec0.get("status"):
                r["inv_status"] = rec0["status"]
            prev = r["_prev"]
            if rec0.get("invoice_rate") is not None:
                if prev["inv_rate"] is not None and rec0["invoice_rate"] != prev["inv_rate"]:
                    flags.append(make_flag("warn", "invoice_rate_changed",
                                           f"Invoice rate {prev['inv_rate'].normalize()} -> {rec0['invoice_rate'].normalize()}. Consultant rate is kept at last payroll's value unless you change it.", r, "inv_rate"))
                r["inv_rate"] = rec0["invoice_rate"]
            if rec0.get("consultant_rate") is not None and r["cons_rate"] is not None and rec0["consultant_rate"] != r["cons_rate"]:
                flags.append(make_flag("warn", "consultant_rate_differs",
                                       f"Invoice sheet consultant rate {rec0['consultant_rate'].normalize()} vs payroll {r['cons_rate'].normalize()} (payroll value kept).",
                                       r, "cons_rate", {"cons_rate": rec0["consultant_rate"]}))
            if rec0.get("consultant_pct") is not None and r["cons_pct"] is not None and rec0["consultant_pct"] != r["cons_pct"]:
                flags.append(make_flag("warn", "consultant_pct_differs",
                                       f"Invoice sheet consultant % {rec0['consultant_pct'].normalize()} vs payroll {r['cons_pct'].normalize()} (payroll value kept).",
                                       r, "cons_pct", {"cons_pct": rec0["consultant_pct"]}))
            if r["hours"] is not None and prev["hours"]:
                if abs(r["hours"] - prev["hours"]) / prev["hours"] > HOURS_SWING:
                    flags.append(make_flag("warn", "hours_changed",
                                           f"Hours {fmt_num(prev['hours'])} last month -> {fmt_num(r['hours'])} now. Check for missing days.", r, "hours"))
            if r["hours"] is not None and r["hours"] > HOURS_HIGH:
                flags.append(make_flag("warn", "hours_high", f"{fmt_num(r['hours'])} hours is unusually high.", r, "hours"))
            if r["hours"] is not None and r["inv_hours"] is not None and r["hours"] < r["inv_hours"] and len(grp) == 1:
                flags.append(make_flag("info", "payroll_lt_invoice",
                                       f"Payroll hours {fmt_num(r['hours'])} are less than invoice hours {fmt_num(r['inv_hours'])}. Intended?", r, "hours"))

    # ---- expense rows follow the parent's hours
    by_uid = {r["uid"]: r for r in rows}
    for r in rows:
        if is_expense(r) and r.get("parent_uid"):
            p = by_uid[r["parent_uid"]]
            r["hours"], r["inv_hours"] = p["hours"], p["inv_hours"]

    # ---- invoice lines that matched nobody -> new employee placeholder (needs set-up)
    for i, inv in enumerate(invoices):
        if i in used:
            continue
        hrs = inv.get("payroll_hours") if inv.get("payroll_hours") is not None else inv.get("invoice_hours")
        r = {k: None for k in INPUT_KEYS}
        start_s, end_s = start.isoformat(), end.isoformat()
        r.update({
            "uid": _uid(), "block": "regular", "ptype": "Regular", "emp_id": inv["id"], "name": inv["name"],
            "vendor": inv.get("vendor", ""), "hours": hrs, "inv_hours": inv.get("invoice_hours"),
            "inv_rate": inv.get("invoice_rate"), "cons_rate": inv.get("consultant_rate"), "cons_pct": inv.get("consultant_pct"),
            "comments": "", "pp_month": (run_date - dt.timedelta(days=1)).isoformat(),
            "pay_period": fmt_period(start, end), "pp_start": start_s, "pp_end": end_s,
            "ae_override": None, "ao_override": None, "excluded": False, "parent_uid": None, "hi_carrier": None,
            "hi_employer": None, "_prev": {"hours": None, "hi": None}, "inv_hours_text": None, "inv_status": inv.get("status", ""),
        })
        flags.append(make_flag("error", "new_employee",
                               "In the invoice sheet but not in last payroll. Fill Payment Term, Consultant Rate/% and ADP ids (or delete the row if it is not payroll).", r, "cons_rate"))
        rows.append(r)

    # ---- health insurance
    carrier_total = sum((h["amount"] for h in hi_recs), ZERO)
    matched_h, employer_total, deducted_total = set(), ZERO, ZERO
    emps = {}
    for r in rows:
        if not is_expense(r):
            emps.setdefault(emp_key(r), []).append(r)
    employer_paid = {id_key(k): D(v, ZERO) for k, v in (rules.get("hi_employer_paid") or {}).items()}
    for ek, erows in emps.items():
        first = erows[0]
        recs = [(i, h) for i, h in enumerate(hi_recs) if same_employee(first["emp_id"], first["name"], h.get("id"), h["name"])]
        prev_hi = sum(((x.get("_prev") or {}).get("hi") or ZERO for x in erows), ZERO)
        if not recs:
            if prev_hi > 0:
                flags.append(make_flag("warn", "hi_missing_in_carrier",
                                       f"Health insurance was {prev_hi} last month but this employee is not in the carrier file. No deduction applied - confirm coverage ended.",
                                       erows[0], "hi"))
            continue
        for i, _h in recs:
            matched_h.add(i)
        amount = sum((h["amount"] for _, h in recs), ZERO)
        plan = ", ".join(sorted({h.get("plan") for _, h in recs if h.get("plan")}))
        paid_by_co = min(employer_paid.get(id_key(first["emp_id"]), ZERO), amount)
        deduction = amount - paid_by_co
        target = next((x for x in erows if (x.get("_prev") or {}).get("hi")), None) or \
            next((x for x in erows if x["block"] == "regular"), erows[0])
        target["hi"], target["hi_carrier"], target["hi_employer"] = deduction, amount, paid_by_co
        employer_total += paid_by_co
        deducted_total += deduction
        if len(recs) > 1:
            flags.append(make_flag("info", "hi_multiple_lines", f"{len(recs)} carrier lines summed to {amount}.", target, "hi"))
        if deduction != prev_hi:
            flags.append(make_flag("warn", "hi_changed",
                                   f"Health insurance deduction {prev_hi} last month -> {deduction} now"
                                   + (f" (carrier {amount}, employer pays {paid_by_co})" if paid_by_co else f" (carrier {amount})")
                                   + (f", plan: {plan}" if plan else "") + ".", target, "hi"))
    unmatched_total = ZERO
    for i, h in enumerate(hi_recs):
        if i not in matched_h:
            unmatched_total += h["amount"]
            flags.append(make_flag("warn", "hi_not_in_payroll",
                                   f"Carrier line for '{h['name']}' ({h['amount']}) matches nobody in payroll. Not deducted.", None, None))

    for r in rows:
        r.pop("_prev", None)
    adv_after = (baseline.get("summary") or {}).get("advance_after")
    state = {
        "rows": rows, "flags": flags, "run_date": run_date.isoformat(),
        "pay_period": fmt_period(start, end),
        "carrier_total": carrier_total, "hi_deducted": deducted_total, "hi_employer": employer_total,
        "hi_unmatched": unmatched_total, "advance_before": adv_after,
    }
    return state


def _vkey(v):
    from .util import vendor_key
    return vendor_key(v)


def _split_cap(rules, row):
    for k, v in (rules.get("split") or {}).items():
        if id_key(k) == id_key(row.get("emp_id")):
            return D(v.get("regular_hours"))
    return None


# ------------------------------------------------------------------ validation / checks / summary
def active(state):
    return [r for r in state["rows"] if not r.get("excluded")]


def validate(state):
    """Live blocking errors (recomputed after every edit)."""
    errs = []
    seen = {}
    for r in active(state):
        who = f"{r.get('name') or '?'} · {r.get('vendor') or ''}".strip(" ·")
        def add(msg, field):
            errs.append({"uid": r["uid"], "field": field, "message": msg, "who": who})
        if not r.get("emp_id") or not r.get("name"):
            add("Employee ID and name are required.", "name")
        if r.get("hours") is None:
            add("Payroll hours missing.", "hours")
        elif r["hours"] < 0:
            add("Payroll hours cannot be negative.", "hours")
        if r.get("cons_rate") is None:
            add("Consultant rate missing.", "cons_rate")
        if r.get("cons_pct") is None:
            add("Consultant % missing.", "cons_pct")
        elif not (ZERO < r["cons_pct"] <= Decimal("1.0")):
            add("Consultant % must be between 0 and 1 (e.g. 0.8).", "cons_pct")
        if not is_expense(r):
            k = (emp_key(r), _vkey(r.get("vendor")), r["block"])
            if k in seen:
                add("Duplicate row: same employee, vendor and block already listed.", "name")
            seen[k] = True
    return errs


def _distinct(rows):
    return len({emp_key(r) for r in rows})


def summary(state):
    rows = active(state)
    comp = {r["uid"]: compute(r) for r in rows}
    reg = [r for r in rows if r["block"] == "regular"]
    mps = [r for r in rows if r["block"] == "mps"]
    g = lambda rs: sum((comp[r["uid"]]["W"] or ZERO for r in rs), ZERO)
    manual = [r for r in reg if (r.get("mode") or "").lower() == "manual"]
    total_ded = sum((r.get("deduct") or ZERO for r in rows), ZERO)
    s = {
        "employees": _distinct(reg), "regular_gross": g(reg), "mps_gross": g(mps),
        "manual_employees": _distinct(manual), "manual_gross": g(manual),
        "auto_gross": g(reg) - g(manual),
        "hi_total": sum((r.get("hi") or ZERO for r in rows), ZERO),
        "deductions_total": total_ded,
        "net_total": sum((comp[r["uid"]]["AC"] or ZERO for r in rows), ZERO),
        "rows": len(rows), "mps_rows": len(mps),
    }
    s["auto_employees"] = s["employees"] - s["manual_employees"]
    ab = state.get("advance_before")
    s["advance_before"] = ab
    s["advance_after"] = (ab - total_ded) if ab is not None else None
    return s


def checks(state):
    """Independent reconciliations. All must be OK before the month can be closed."""
    out = []
    rows = active(state)
    comp = {r["uid"]: compute(r) for r in rows}

    def add(name, ok, detail):
        out.append({"name": name, "ok": bool(ok), "detail": detail})

    bad_adp = [r for r in rows if comp[r["uid"]]["AF"] and comp[r["uid"]]["AE"] and
               abs(comp[r["uid"]]["AF"] * comp[r["uid"]]["AE"] - comp[r["uid"]]["W"]) > Decimal("0.01")]
    add("ADP hours x ADP rate = net gross amount (every row)", not bad_adp, f"{len(bad_adp)} rows off")
    bad_net = [r for r in rows if comp[r["uid"]]["AC"] is not None and
               abs(comp[r["uid"]]["AC"] - (comp[r["uid"]]["W"] + (r.get("bonus") or ZERO) - comp[r["uid"]]["AB"])) > Decimal("0.001")]
    add("Net gross = net gross amount + bonus - deductions (every row)", not bad_net, f"{len(bad_net)} rows off")
    s = summary(state)
    add("Manual gross + auto gross = regular gross", s["manual_gross"] + s["auto_gross"] == s["regular_gross"], str(q2(s["regular_gross"])))
    ct = state.get("carrier_total")
    if ct:
        recon = s["hi_total"] + (state.get("hi_employer") or ZERO) + (state.get("hi_unmatched") or ZERO)
        add("Health insurance: deducted + employer-paid + unmatched = carrier file total",
            abs(recon - ct) <= Decimal("0.01") and s["hi_total"] == sum((r.get("hi") or ZERO for r in rows), ZERO),
            f"{q2(recon)} vs carrier {q2(ct)}")
    if s["advance_before"] is not None:
        add("Advance before - deductions = advance after", s["advance_before"] - s["deductions_total"] == s["advance_after"],
            f"{q2(s['advance_before'])} - {q2(s['deductions_total'])} = {q2(s['advance_after'])}")
    unmatched_exp = [r for r in rows if is_expense(r) and not r.get("parent_uid")]
    add("Every expense row is linked to an employee row", not unmatched_exp, f"{len(unmatched_exp)} unlinked")
    return out


def readiness(state):
    errs = validate(state)
    unacked = [f for f in state["flags"] if f["severity"] in ("warn", "error") and not f["acked"]
               and not _flag_resolved(f, state)]
    chk = checks(state)
    return {"errors": errs, "unacked": unacked, "checks": chk,
            "can_download": not errs and all(c["ok"] for c in chk),
            "can_close": not errs and not unacked and all(c["ok"] for c in chk)}


def _flag_resolved(f, state):
    """Error flags that point to a field resolve themselves once the field has a value."""
    if f["severity"] != "error" or not f.get("uid"):
        return False
    row = next((r for r in state["rows"] if r["uid"] == f["uid"]), None)
    if row is None or row.get("excluded"):
        return True
    return not any(e["uid"] == f["uid"] for e in validate(state))


# ------------------------------------------------------------------ closing a month -> next baseline
def to_baseline(state):
    rows = []
    for r in state["rows"]:
        b = {k: r.get(k) for k in INPUT_KEYS}
        c = compute(r)
        b.update({"block": r["block"], "ae_raw": c["AE"], "ao_raw": c["AO"], "one_time": False,
                  "ae_override": r.get("ae_override"), "ao_override": r.get("ao_override")})
        rows.append(b)
    s = summary(state)
    return {"rows": rows, "summary": {"pay_period": state["pay_period"], "advance_before": s["advance_before"],
                                       "advance_after": s["advance_after"], "hi_total": state.get("carrier_total")}}
