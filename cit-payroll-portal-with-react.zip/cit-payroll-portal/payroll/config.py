"""Default column-name synonyms and rules. Users extend these in Settings (stored in data/)."""

DEFAULT_MAPPINGS = {
    "invoices": {
        "name": ["employee name", "consultant name", "consultant", "employee", "resource name", "resource", "name"],
        "id": ["employee id", "emp id", "consultant id", "cit id", "id"],
        "vendor": ["vendor name", "vendor", "end client", "client name", "client"],
        "invoice_hours": ["invoice hours", "billed hours", "billable hours", "total hours", "hours billed", "hrs", "hours"],
        "payroll_hours": ["payroll hours", "payroll hrs", "hours to pay", "pay hours", "payable hours"],
        "invoice_rate": ["invoice rate", "bill rate", "billing rate", "client rate"],
        "consultant_rate": ["consultant rate", "pay rate base", "cons rate"],
        "consultant_pct": ["consultant %", "consultant pct", "consultant percent", "payout %", "pay %"],
        "status": ["invoice payment status", "payment status", "paid status", "invoice status"],
    },
    "health": {
        "name": ["employee name", "member name", "subscriber name", "subscriber", "employee", "member", "name"],
        "id": ["employee id", "emp id", "member id", "id"],
        "plan": ["coverage tier", "tier", "plan", "coverage", "coverage type"],
        "amount": ["premium", "total premium", "monthly premium", "amount", "total amount", "cost", "employee cost", "employee premium"],
    },
}

REQUIRED = {
    "invoices": ["name", "invoice_hours"],
    "health": ["name", "amount"],
}

# Seed rules (editable in Settings). Derived from the Oct-15-2026 payroll:
#   CIT-027 Jandalamaram: carrier 1,680.65, employee pays 1,171.35  -> employer pays 509.30
#   CIT-085 Avuthu: Regular row runs 168 hrs, the rest of the invoice hours go to the MPS row
DEFAULT_RULES = {
    "hi_employer_paid": {"CIT-027": "509.30"},
    "split": {"CIT-085": {"regular_hours": "168"}},
}

MAX_UPLOAD_MB = 25
ALLOWED_EXT = {".xlsx", ".xlsm", ".csv"}
