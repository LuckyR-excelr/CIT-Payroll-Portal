"""The 46 payroll columns (A..AT) exactly as in the CIT payroll sheet.
key=None means the column is calculated by formula."""

COLUMNS = [
    ("A", "PayrollType", "ptype"), ("B", "Employee ID", "emp_id"), ("C", "Employee Name", "name"),
    ("D", "Run For", "run_for"), ("E", "Payment Term", "term"), ("F", "Comments", "comments"),
    ("G", "Primary/Secondary", "pri_sec"), ("H", "Billing Frequency", "billing"), ("I", "Mode of Payment", "mode"),
    ("J", "Invoice Payment Status", "inv_status"), ("K", "Pay period Month", "pp_month"), ("L", "Pay Period", "pay_period"),
    ("M", "Payroll  Hours", "hours"), ("N", "Hrs Validation per Invoice Sheet", "inv_hours"), ("O", "Invoice Rate", "inv_rate"),
    ("P", "Vendor Name", "vendor"), ("Q", "Consultant Rate", "cons_rate"), ("R", "Consultant %", "cons_pct"),
    ("S", "Pay rate", None), ("T", "Expenses Reimbursement", "expenses"), ("U", "Gross Amount", None),
    ("V", "Paid Expenses", "paid_exp"), ("W", "Net Gross Amount", None), ("X", "Adjusted Hours", None),
    ("Y", "Bonus", "bonus"), ("Z", "Deductions", "deduct"), ("AA", "Employee Health Insurance Expenses", "hi"),
    ("AB", "Total Deduction", None), ("AC", "Net Gross", None), ("AD", "LCA Wages", "lca"),
    ("AE", "ADP Rate", None), ("AF", "ADP Hours", None), ("AG", "EMT", "emt"), ("AH", "CNT", "cnt"),
    ("AI", "IID", "iid"), ("AJ", "Pay Frequency", "pay_freq"), ("AK", "Pay Period Start", "pp_start"),
    ("AL", "Pay Period End", "pp_end"), ("AM", "Employee Id", "adp_id"), ("AN", "Earnings Code", "earn_code"),
    ("AO", "Pay Hours", None), ("AP", "Dollars", "dollars"), ("AQ", "Separate Check", "sep_check"),
    ("AR", "Department Number", "dept"), ("AS", "Rate Code", "rate_code"), ("AT", "Job Code", "job_code"),
]

# input keys that hold money / hours / rates -> stored as Decimal
NUMERIC_KEYS = {"hours", "inv_hours", "inv_rate", "cons_rate", "cons_pct", "expenses", "paid_exp",
                "bonus", "deduct", "hi", "lca", "ae_override", "ao_override", "hi_carrier", "hi_employer"}

# fields the review grid may edit
EDITABLE = {"hours", "inv_hours", "inv_rate", "vendor", "cons_rate", "cons_pct", "bonus", "deduct", "hi",
            "ae_override", "ao_override", "comments", "expenses", "paid_exp", "block", "mode", "term", "name",
            "emp_id", "lca", "pri_sec", "ptype"}
