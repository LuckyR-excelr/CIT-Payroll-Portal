"""Read the three monthly inputs: previous payroll (baseline), CIT invoice sheet, health-insurance file.
Nothing is hard-coded: invoice / health columns are found by header synonyms (editable in Settings)."""
import csv
import datetime as dt
from collections import Counter

from openpyxl import load_workbook

from .columns import COLUMNS, NUMERIC_KEYS
from .config import DEFAULT_MAPPINGS, REQUIRED
from .util import D, norm_header, id_key


class MappingError(Exception):
    """Raised when required columns cannot be located; carries what we did find."""

    def __init__(self, kind, message, headers=None, sheets=None):
        super().__init__(message)
        self.kind, self.headers, self.sheets = kind, headers or [], sheets or []


# ---------------------------------------------------------------- generic table reader
def _sheets(path, sheet=None):
    if str(path).lower().endswith(".csv"):
        with open(path, newline="", encoding="utf-8-sig") as f:
            yield "csv", [list(r) for r in csv.reader(f)]
        return
    wb = load_workbook(path, data_only=True, read_only=True)
    try:
        names = [sheet] if sheet and sheet in wb.sheetnames else wb.sheetnames
        for n in names:
            yield n, [list(r) for r in wb[n].iter_rows(values_only=True)]
    finally:
        wb.close()


def merge_mappings(custom):
    out = {k: {f: list(v) for f, v in d.items()} for k, d in DEFAULT_MAPPINGS.items()}
    for kind, fields in (custom or {}).items():
        for field, names in fields.items():
            base = out.setdefault(kind, {}).setdefault(field, [])
            out[kind][field] = [n for n in names if n] + [b for b in base if b not in names]
    return out


def _detect(rows, syn, required):
    best = None
    for hi, row in enumerate(rows[:30]):
        heads = [norm_header(c) for c in row]
        if not any(heads):
            continue
        mapping, used = {}, set()
        order = sorted(syn, key=lambda f: (f not in required, f))
        for field in order:
            idx = None
            for n in syn[field]:                       # exact header match first
                nn = norm_header(n)
                if nn in heads and heads.index(nn) not in used:
                    idx = heads.index(nn)
                    break
            if idx is None:                            # then "header contains synonym"
                for n in syn[field]:
                    nn = norm_header(n)
                    if len(nn) < 6:
                        continue
                    for j, h in enumerate(heads):
                        if h and nn in h and j not in used:
                            idx = j
                            break
                    if idx is not None:
                        break
            if idx is not None:
                mapping[field] = idx
                used.add(idx)
        if all(f in mapping for f in required):
            score = len(mapping)
            if best is None or score > best[0]:
                best = (score, hi, mapping)
    return best


def _pct(v):
    d = D(v)
    if d is None:
        return None
    return d / 100 if d > Decimal_1_5 else d


Decimal_1_5 = D("1.5")


def read_table(path, kind, custom_mappings=None, sheet=None):
    """Return (records, meta). Raises MappingError if required columns are missing."""
    syn = merge_mappings(custom_mappings)[kind]
    required = REQUIRED[kind]
    best, seen_sheets, first_headers = None, [], []
    for sname, rows in _sheets(path, sheet):
        seen_sheets.append(sname)
        if not first_headers and rows:
            first_headers = [str(c) for c in rows[0] if c is not None]
        found = _detect(rows, syn, required)
        if found and (best is None or found[0] > best[0][0]):
            best = (found, sname, rows)
    if not best:
        raise MappingError(kind, f"Could not find the required columns {required} in the {kind} file.",
                           first_headers, seen_sheets)
    (score, hrow, mapping), sname, rows = best
    records = []
    for i, row in enumerate(rows[hrow + 1:], start=hrow + 2):
        def cell(f):
            j = mapping.get(f)
            return row[j] if j is not None and j < len(row) else None
        name = cell("name")
        if name is None or str(name).strip() == "" or "total" in str(name).lower():
            continue
        rec = {"name": str(name).strip(), "src_row": i, "sheet": sname}
        rec["id"] = str(cell("id")).strip() if cell("id") not in (None, "") else ""
        for f in ("vendor", "plan", "status"):
            if f in mapping:
                v = cell(f)
                rec[f] = str(v).strip() if v not in (None, "") else ""
        for f in ("invoice_hours", "payroll_hours", "invoice_rate", "consultant_rate", "amount"):
            if f in mapping:
                rec[f] = D(cell(f))
        if "consultant_pct" in mapping:
            rec["consultant_pct"] = _pct(cell("consultant_pct"))
        if kind == "invoices" and rec.get("invoice_hours") is None and rec.get("payroll_hours") is None:
            continue
        if kind == "health" and rec.get("amount") is None:
            continue
        records.append(rec)
    meta = {"sheet": sname, "header_row": hrow + 1, "columns": {k: v + 1 for k, v in mapping.items()},
            "records": len(records)}
    return records, meta


# ---------------------------------------------------------------- baseline (previous payroll)
def _find_payroll_sheet(wb):
    for ws in wb.worksheets:
        b1, c1 = ws.cell(1, 2).value, ws.cell(1, 3).value
        if norm_header(b1) == "employee id" and norm_header(c1) == "employee name":
            return ws
    raise MappingError("baseline", "No sheet with 'Employee ID' / 'Employee Name' headers in columns B/C.",
                       [], wb.sheetnames)


def read_baseline(path):
    """Parse a CIT payroll workbook (cached values) into rows + summary."""
    wb = load_workbook(path, data_only=True)
    ws = _find_payroll_sheet(wb)
    rows, block, seen_total = [], "regular", False
    keys = [(i + 1, c[2]) for i, c in enumerate(COLUMNS) if c[2]]
    for r in range(2, ws.max_row + 1):
        emp_id, name = ws.cell(r, 2).value, ws.cell(r, 3).value
        label = ws.cell(r, 1).value
        if not emp_id and not name:
            if any(ws.cell(r, c).value is not None for c in (21, 23)):   # totals row (U/W sums)
                seen_total = True
            if isinstance(label, str) and "summary" in label.lower():
                break
            continue
        if label not in ("Regular", "MPS") or not emp_id:
            continue
        if seen_total:
            block = "mps"
        row = {"block": block}
        for col, key in keys:
            v = ws.cell(r, col).value
            if isinstance(v, dt.datetime):
                v = v.date().isoformat()
            if key in NUMERIC_KEYS:
                v = D(v)
            elif isinstance(v, str):
                v = v.strip()
            row[key] = v
        row["ae_raw"] = D(ws.cell(r, 31).value)
        row["ao_raw"] = D(ws.cell(r, 41).value)
        row["gross_raw"] = D(ws.cell(r, 23).value)
        row["src_row"] = r
        rows.append(row)
    if not rows:
        raise MappingError("baseline", "No employee rows found in the payroll sheet.", [], wb.sheetnames)
    dominant = Counter(r["pay_period"] for r in rows if r.get("pay_period")).most_common(1)
    dominant = dominant[0][0] if dominant else None
    for r in rows:
        r["one_time"] = bool(dominant and r.get("pay_period") and r["pay_period"] != dominant)
    summary = {"sheet": ws.title, "pay_period": dominant}
    for r in range(1, ws.max_row + 1):
        a = str(ws.cell(r, 1).value or "").lower()
        if "advance after" in a:
            summary["advance_after"] = D(ws.cell(r, 2).value)
        elif "advance before" in a:
            summary["advance_before"] = D(ws.cell(r, 2).value)
        elif a.startswith("health insurance"):
            summary["hi_total"] = D(ws.cell(r, 2).value)
    return {"rows": rows, "summary": summary}
