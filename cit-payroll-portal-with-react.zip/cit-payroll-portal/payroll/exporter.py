"""Write the monthly payroll workbook in the same 46-column layout as the CIT sheet, with live formulas,
a summary block, a Checks sheet (formulas), a Review Flags sheet and an Inputs sheet."""
import datetime as dt

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

from .columns import COLUMNS
from .engine import compute, is_expense, summary, active
from .util import ZERO, num, to_date

HDR_FILL = PatternFill("solid", fgColor="FFC000")
BLUE = PatternFill("solid", fgColor="DDEBF7")
MONEY = "#,##0.00"
HOURS = "0.###"
DATE = "m/d/yyyy"
IDX = {c[0]: i + 1 for i, c in enumerate(COLUMNS)}
LCOL = {c[2]: c[0] for c in COLUMNS if c[2]}
MONEY_COLS = {"O", "Q", "S", "T", "U", "V", "W", "Y", "Z", "AA", "AB", "AC", "AD", "AE", "AP"}
HOUR_COLS = {"M", "N", "X", "AF", "AO"}


def _d(v):
    if v in (None, ""):
        return None
    return to_date(v)


def _write_row(ws, r, row, block):
    for col, header, key in COLUMNS:
        if block == "mps" and IDX[col] > IDX["AF"]:
            continue
        c = ws[f"{col}{r}"]
        v = None
        if key == "ptype":
            v = row.get("ptype") or ("MPS" if block == "mps" else "Regular")
        elif key in ("pp_month", "pp_start", "pp_end"):
            v = _d(row.get(key))
        elif key == "inv_hours":
            v = row.get("inv_hours_text") or num(row.get("inv_hours"))
        elif key is not None:
            v = row.get(key)
            if hasattr(v, "as_tuple"):
                v = num(v)
            if key == "deduct" and v is None and block == "mps":
                v = None
        if v not in (None, ""):
            c.value = v
            if isinstance(v, str):
                c.data_type = "s"          # never let uploaded text become a formula
        if col in MONEY_COLS:
            c.number_format = MONEY
        elif col in HOUR_COLS:
            c.number_format = HOURS
        elif col in ("K", "AK", "AL"):
            c.number_format = DATE
    # formulas
    exp = is_expense(row)
    ws[f"S{r}"] = f"=Q{r}*R{r}"
    ws[f"U{r}"] = f"=(S{r}*M{r})-T{r}"
    ws[f"W{r}"] = f"=U{r}-V{r}"
    ws[f"X{r}"] = 0 if exp else f"=IF(S{r}=0,0,W{r}/S{r})"
    ws[f"AB{r}"] = f"=Z{r}+AA{r}"
    ws[f"AC{r}"] = f"=W{r}+Y{r}-AB{r}"
    ws[f"AE{r}"] = num(row["ae_override"]) if row.get("ae_override") is not None else f"=S{r}"
    ws[f"AF{r}"] = 0 if exp else f"=IF(AE{r}=0,0,W{r}/AE{r})"
    if block == "regular":
        c = compute(row)
        if row.get("ao_override") is not None or exp or row.get("ae_override") is not None:
            ws[f"AO{r}"] = num(c["AO"])
        else:
            ws[f"AO{r}"] = f"=M{r}"
    for col in ("S", "U", "W", "AB", "AC", "AE"):
        ws[f"{col}{r}"].number_format = MONEY
    for col in ("X", "AF", "AO"):
        ws[f"{col}{r}"].number_format = HOURS


def build_workbook(state, ready, meta=None, draft=False):
    meta = meta or {}
    run = to_date(state["run_date"])
    wb = Workbook()
    ws = wb.active
    sheet = f"{run:%b}-{run:%d} payroll"
    ws.title = ("DRAFT " + sheet) if draft else sheet
    P = f"'{ws.title}'!"
    for i, (col, header, _k) in enumerate(COLUMNS, start=1):
        c = ws.cell(1, i, header)
        c.font, c.fill = Font(bold=True), HDR_FILL
        c.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
    ws.row_dimensions[1].height = 32
    ws.freeze_panes = "D2"

    rows = active(state)
    reg = [r for r in rows if r["block"] == "regular"]
    mps = [r for r in rows if r["block"] == "mps"]
    r = 2
    reg_first = r
    for row in reg:
        _write_row(ws, r, row, "regular")
        r += 1
    reg_last = r - 1
    tot = r
    for col in ("U", "W", "X", "Y", "Z", "AA", "AB", "AC", "AF"):
        ws[f"{col}{tot}"] = f"=SUM({col}{reg_first}:{col}{reg_last})"
        ws[f"{col}{tot}"].font = Font(bold=True)
        ws[f"{col}{tot}"].number_format = MONEY if col not in ("X", "AF") else HOURS
        ws[f"{col}{tot}"].fill = BLUE
    r = tot + 3
    mps_first = r
    for row in mps:
        _write_row(ws, r, row, "mps")
        r += 1
    mps_last = r - 1
    r += 1

    s = summary(state)
    ws[f"A{r}"], ws[f"B{r}"], ws[f"C{r}"] = "CIT - Summary", f"{run:%b %d %Y} Regular Payroll", "Gross"
    for c in "ABC":
        ws[f"{c}{r}"].font, ws[f"{c}{r}"].fill = Font(bold=True), BLUE
    rr = r + 1
    I_rng, W_rng = f"I{reg_first}:I{reg_last}", f"W{reg_first}:W{reg_last}"
    lines = [
        ("No of Employees:  ", s["employees"], f"=W{tot}"),
        ("Manual employees :  ", s["manual_employees"], f'=SUMIF({I_rng},"Manual",{W_rng})'),
        ("Auto employee: ", f"=B{rr}-B{rr+1}", f"=C{rr}-C{rr+1}"),
        ("Run Date ", run, None),
        ("Advance Before payroll: ", num(s["advance_before"]), None),
        ("Advance after payroll:", f"=B{rr+4}-Z{tot}" if s["advance_before"] is not None else None, None),
        ("Health insurance amount", num(state.get("carrier_total")), "Collected"),
    ]
    sum_rows = {}
    for i, (a, b, c) in enumerate(lines):
        ws[f"A{rr+i}"] = a
        if b is not None:
            ws[f"B{rr+i}"] = b
        if c is not None:
            ws[f"C{rr+i}"] = c
        sum_rows[a.strip()] = rr + i
    ws[f"B{rr+3}"].number_format = DATE
    for i in (4, 5, 6):
        ws[f"B{rr+i}"].number_format = MONEY
    for i in (0, 1, 2):
        ws[f"C{rr+i}"].number_format = MONEY
    ws[f"B{rr+6}"].number_format = MONEY

    widths = {"A": 12, "B": 13, "C": 30, "D": 9, "E": 9, "F": 40, "G": 11, "H": 12, "I": 10, "J": 12, "K": 12, "L": 23,
              "M": 10, "N": 11, "O": 11, "P": 26, "Q": 11, "R": 10, "S": 11, "T": 11, "U": 13, "V": 10, "W": 13,
              "X": 10, "Y": 9, "Z": 11, "AA": 13, "AB": 12, "AC": 13, "AD": 12, "AE": 11, "AF": 10}
    for i in range(1, len(COLUMNS) + 1):
        L = get_column_letter(i)
        ws.column_dimensions[L].width = widths.get(L, 12)

    _checks_sheet(wb, P, state, s, reg_first, reg_last, mps_first, mps_last, tot, sum_rows)
    _flags_sheet(wb, state, ready, draft)
    _inputs_sheet(wb, state, meta, draft)
    return wb


def _checks_sheet(wb, P, state, s, rf, rl, mf, ml, tot, sr):
    ck = wb.create_sheet("Checks")
    ck.append(["Check", "Result", "Expected", "Difference", "Status"])
    for c in ck[1]:
        c.font, c.fill = Font(bold=True), HDR_FILL
    rngs = [(rf, rl)] + ([(mf, ml)] if ml >= mf else [])

    def sp(expr):   # SUMPRODUCT over both blocks
        return "=" + "+".join(f"SUMPRODUCT({expr.format(a=a, b=b)})" for a, b in rngs)

    def add(name, res, exp, tol=0.01):
        r = ck.max_row + 1
        ck.append([name, res, exp, f"=B{r}-C{r}", f'=IF(ABS(D{r})<={tol},"OK","CHECK")'])
        for c in "BCD":
            ck[f"{c}{r}"].number_format = "#,##0.000"

    add("Summary gross = sum of Regular rows", f"={P}C{sr['No of Employees:']}", f"=SUM({P}W{rf}:W{rl})")
    add("Manual + Auto gross = total Regular gross",
        f"={P}C{sr['Manual employees :']}+{P}C{sr['Auto employee:']}", f"={P}C{sr['No of Employees:']}")
    add("Pay rate = Consultant rate x %", sp(f"ABS({P}S{{a}}:S{{b}}-{P}Q{{a}}:Q{{b}}*{P}R{{a}}:R{{b}})"), 0, 0.001)
    add("Gross = Pay rate x Hours - Expenses", sp(f"ABS({P}U{{a}}:U{{b}}-({P}S{{a}}:S{{b}}*{P}M{{a}}:M{{b}}-{P}T{{a}}:T{{b}}))"), 0, 0.001)
    add("Net Gross = Net Gross Amount + Bonus - Total Deduction",
        sp(f"ABS({P}AC{{a}}:AC{{b}}-({P}W{{a}}:W{{b}}+{P}Y{{a}}:Y{{b}}-{P}AB{{a}}:AB{{b}}))"), 0, 0.001)
    add("Total Deduction = Deductions + Health insurance",
        sp(f"ABS({P}AB{{a}}:AB{{b}}-({P}Z{{a}}:Z{{b}}+{P}AA{{a}}:AA{{b}}))"), 0, 0.001)
    add("ADP hours x ADP rate = Net Gross Amount",
        sp(f"({P}AF{{a}}:AF{{b}}>0)*ABS({P}AF{{a}}:AF{{b}}*{P}AE{{a}}:AE{{b}}-{P}W{{a}}:W{{b}})"), 0, 0.001)
    base = ck.max_row + 3
    ck[f"A{base}"], ck[f"B{base}"] = "Input: carrier file total", num(state.get("carrier_total")) or 0
    ck[f"A{base+1}"], ck[f"B{base+1}"] = "Input: employer-paid portion (Settings rule)", num(state.get("hi_employer")) or 0
    ck[f"A{base+2}"], ck[f"B{base+2}"] = "Input: carrier lines not matched to payroll", num(state.get("hi_unmatched")) or 0
    for i in range(3):
        ck[f"B{base+i}"].number_format = MONEY
    if state.get("carrier_total"):
        add("Health insurance deducted + employer-paid + unmatched = carrier total",
            f"={P}AA{tot}+B{base+1}+B{base+2}", f"=B{base}")
    if s["advance_before"] is not None:
        add("Advance before - deductions = advance after",
            f"={P}B{sr['Advance Before payroll:']}-{P}Z{tot}", f"={P}B{sr['Advance after payroll:']}")
    last = ck.max_row
    ck.cell(last + 2, 1, "ALL CHECKS").font = Font(bold=True)
    ck.cell(last + 2, 5, f'=IF(COUNTIF(E2:E{last},"CHECK")=0,"OK","CHECK")').font = Font(bold=True)
    ck.column_dimensions["A"].width = 70
    for c in "BCD":
        ck.column_dimensions[c].width = 16


def _flags_sheet(wb, state, ready, draft):
    fs = wb.create_sheet("Review Flags")
    fs.append(["Severity", "Employee / vendor", "Message", "Status"])
    for c in fs[1]:
        c.font, c.fill = Font(bold=True), HDR_FILL
    for e in ready["errors"]:
        fs.append(["ERROR", e["who"], e["message"], "OPEN"])
    for f in state["flags"]:
        if f["severity"] == "info":
            status = "info"
        else:
            status = "Acknowledged" if f["acked"] else "OPEN"
        fs.append([f["severity"].upper(), f.get("who", ""), f["message"], status])
    fs.column_dimensions["A"].width, fs.column_dimensions["B"].width = 10, 40
    fs.column_dimensions["C"].width, fs.column_dimensions["D"].width = 110, 14
    for row in fs.iter_rows(min_row=2):
        row[2].alignment = Alignment(wrap_text=True, vertical="top")


def _inputs_sheet(wb, state, meta, draft):
    ins = wb.create_sheet("Inputs")
    ins.append(["Item", "Value"])
    for c in ins[1]:
        c.font, c.fill = Font(bold=True), HDR_FILL
    items = [("Status", "DRAFT - unresolved errors, do not upload to ADP" if draft else "Final - all errors resolved, all checks OK"),
             ("Run date", to_date(state["run_date"]).isoformat()), ("Pay period", state["pay_period"]),
             ("Generated", dt.datetime.now().strftime("%Y-%m-%d %H:%M"))]
    for k, v in (meta or {}).items():
        items.append((k, str(v)))
    for it in items:
        ins.append(list(it))
    if draft:
        ins["B2"].font = Font(bold=True, color="C00000")
    ins.column_dimensions["A"].width, ins.column_dimensions["B"].width = 28, 110
