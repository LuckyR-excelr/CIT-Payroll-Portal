"""Tiny file-based storage (JSON). Decimals survive round-trips exactly."""
import json
import os
import shutil
import tempfile
from decimal import Decimal

from .config import DEFAULT_RULES

DATA_DIR = os.environ.get("PORTAL_DATA_DIR", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data"))


def _enc(o):
    if isinstance(o, Decimal):
        return {"__d": str(o)}
    raise TypeError(f"not serialisable: {type(o)}")


def _dec(d):
    return Decimal(d["__d"]) if "__d" in d and len(d) == 1 else d


def path(*parts):
    p = os.path.join(DATA_DIR, *parts)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return p


def save_json(obj, *parts):
    target = path(*parts)
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(target), suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(obj, f, default=_enc, indent=1)
    os.replace(tmp, target)


def load_json(*parts, default=None):
    p = os.path.join(DATA_DIR, *parts)
    if not os.path.exists(p):
        return default
    with open(p, encoding="utf-8") as f:
        return json.load(f, object_hook=_dec)


# ---- settings
def get_mappings():
    return load_json("mappings.json", default={})


def save_mappings(m):
    save_json(m, "mappings.json")


def get_rules():
    r = load_json("rules.json")
    if r is None:
        r = json.loads(json.dumps(DEFAULT_RULES))
        save_json(r, "rules.json")
    return r


def save_rules(r):
    save_json(r, "rules.json")


# ---- baseline (the payroll the next month is built from)
def get_baseline():
    return load_json("baseline.json")


def save_baseline(b, label):
    old = get_baseline()
    if old:
        save_json(old, "history", f"baseline_before_{label}.json")
    save_json(b, "baseline.json")


# ---- months
def month_ids():
    d = os.path.join(DATA_DIR, "months")
    if not os.path.isdir(d):
        return []
    return sorted((x for x in os.listdir(d) if os.path.exists(os.path.join(d, x, "state.json"))), reverse=True)


def get_month(mid):
    return load_json("months", mid, "state.json")


def save_month(mid, state):
    save_json(state, "months", mid, "state.json")


def input_path(mid, filename):
    return path("months", mid, "inputs", filename)


def delete_month(mid):
    shutil.rmtree(os.path.join(DATA_DIR, "months", mid), ignore_errors=True)
