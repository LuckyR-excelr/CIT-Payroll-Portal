"""Small helpers: exact decimal maths, name / vendor normalisation, dates."""
import re
import datetime as dt
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, ROUND_DOWN

ZERO = Decimal("0")


def D(value, default=None):
    """Convert anything number-like to Decimal. Text such as '202-168' -> default."""
    if value is None or value == "":
        return default
    if isinstance(value, Decimal):
        return value
    if isinstance(value, bool):
        return default
    if isinstance(value, int):
        return Decimal(value)
    if isinstance(value, float):
        return Decimal(repr(value))
    s = str(value).strip().replace("$", "").replace(",", "")
    if s.endswith("%"):
        s = s[:-1]
        try:
            return Decimal(s) / 100
        except InvalidOperation:
            return default
    try:
        return Decimal(s)
    except InvalidOperation:
        return default


def q2(x):
    """Round to cents (half up)."""
    return None if x is None else x.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def trunc3(x):
    """Truncate to 3 decimals (ADP pay hours convention: never exceed the gross)."""
    return None if x is None else x.quantize(Decimal("0.001"), rounding=ROUND_DOWN)


def num(x):
    """Decimal -> float for JSON/Excel (None stays None)."""
    return None if x is None else float(x)


def norm_header(s):
    s = "" if s is None else str(s).lower()
    s = re.sub(r"[^a-z0-9% ]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def name_key(s):
    """'Pabba, Gokul Charan' == 'Gokul Charan Pabba' ; '(Expenses)' suffix ignored."""
    s = (s or "").lower()
    s = re.sub(r"\(.*?\)", "", s)
    s = re.sub(r"[^a-z0-9, ]", "", s)
    if "," in s:
        last, first = s.split(",", 1)
        s = first + " " + last
    toks = sorted(t for t in s.replace(",", " ").split() if t)
    return " ".join(toks)


def letters_key(s):
    """Spacing/order independent key (SaiKiranYadav Ankam == Ankam, Sai Kiran Yadav)."""
    s = re.sub(r"\(.*?\)", "", (s or "").lower())
    return "".join(sorted(re.sub(r"[^a-z0-9]", "", s)))


def id_key(s):
    return re.sub(r"[^A-Z0-9]", "", str(s or "").upper())


_SUFFIX = {"inc", "llc", "corp", "corporation", "ltd", "limited", "co", "company"}


def vendor_key(s):
    toks = [t for t in re.sub(r"[^a-z0-9 ]", " ", (s or "").lower()).split() if t not in _SUFFIX]
    return "".join(toks)


def vendor_match(a, b):
    ka, kb = vendor_key(a), vendor_key(b)
    if not ka or not kb:
        return False
    if ka == kb:
        return True
    short, long_ = sorted((ka, kb), key=len)
    return len(short) >= 4 and short in long_


def same_employee(id_a, name_a, id_b, name_b):
    ia, ib = id_key(id_a), id_key(id_b)
    if ia and ib:
        return ia == ib
    if name_key(name_a) and name_key(name_a) == name_key(name_b):
        return True
    la, lb = letters_key(name_a), letters_key(name_b)
    return bool(la) and la == lb


def last_day(y, m):
    nxt = dt.date(y + (m == 12), (m % 12) + 1, 1)
    return nxt - dt.timedelta(days=1)


def pay_period(run_date):
    """Run on Oct 15 -> pays September (09/01 - 09/30)."""
    y, m = (run_date.year, run_date.month - 1) if run_date.month > 1 else (run_date.year - 1, 12)
    start = dt.date(y, m, 1)
    return start, last_day(y, m)


def fmt_period(start, end):
    return f"{start:%m/%d/%Y}-{end:%m/%d/%Y}"


def to_date(v):
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    return dt.date.fromisoformat(str(v)[:10])
